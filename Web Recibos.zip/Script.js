document.addEventListener('DOMContentLoaded', function() {
    const rowsPerPage = 10; // Número de filas por página
    let currentPage = 1;
    let items;
    let filteredItems;

    // Variable para el nombre específico
    const specificName = "Juan Pérez"; // Cambia esto por el nombre que desees filtrar

    fetch('data.xml')
        .then(response => {
            if (!response.ok) {
                throw new Error(`Error al cargar el archivo XML: ${response.statusText}`);
            }
            return response.text();
        })
        .then(data => {
            let parser = new DOMParser();
            let xmlDoc = parser.parseFromString(data, 'text/xml');
            items = Array.from(xmlDoc.getElementsByTagName('item'));
            if (items.length === 0) {
                throw new Error('No se encontraron elementos <item> en el archivo XML.');
            }

            populateYearFilter();
            applyFilters(); // Aplicar el filtro inicialmente
        })
        .catch(error => console.error(error));

    function populateYearFilter() {
        const yearFilter = document.getElementById('yearFilter');
        let years = new Set(items.map(item => item.getElementsByTagName('periodo')[0].textContent.split('-')[0]));
        years.forEach(year => {
            let option = document.createElement('option');
            option.value = year;
            option.textContent = year;
            yearFilter.appendChild(option);
        });
    }

    function applyFilters() {
        const yearFilter = document.getElementById('yearFilter').value;

        // Filtro por nombre
        filteredItems = items.filter(item => {
            const nombre = item.getElementsByTagName('nombre')[0].textContent;
            return nombre === specificName;
        });

        // Filtro por año
        filteredItems = filteredItems.filter(item => {
            const periodo = item.getElementsByTagName('periodo')[0].textContent;
            const year = periodo.split('-')[0];

            return yearFilter === 'all' || year === yearFilter;
        });

        currentPage = 1; // Resetear a la primera página
        displayTable();
        displayReceiptsCount();
    }

    function displayReceiptsCount() {
        const countElement = document.getElementById('count');
        countElement.textContent = filteredItems.length;
    }

    function displayTable() {
        let tableBody = document.querySelector('#data-table tbody');
        tableBody.innerHTML = '';

        let startIndex = (currentPage - 1) * rowsPerPage;
        let endIndex = Math.min(startIndex + rowsPerPage, filteredItems.length);

        for (let i = startIndex; i < endIndex; i++) {
            let row = document.createElement('tr');

            let nombre = filteredItems[i].getElementsByTagName('nombre')[0].textContent;
            let periodo = filteredItems[i].getElementsByTagName('periodo')[0].textContent;

            let nombreCell = document.createElement('td');
            nombreCell.textContent = nombre;
            row.appendChild(nombreCell);

            let periodoCell = document.createElement('td');
            periodoCell.textContent = periodo;
            row.appendChild(periodoCell);

            tableBody.appendChild(row);
        }

        document.getElementById('pageInfo').textContent = `Página ${currentPage} de ${Math.ceil(filteredItems.length / rowsPerPage)}`;
    }

    document.getElementById('prevPage').addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            displayTable();
        }
    });

    document.getElementById('nextPage').addEventListener('click', () => {
        if (currentPage * rowsPerPage < filteredItems.length) {
            currentPage++;
            displayTable();
        }
    });

    document.getElementById('applyFilters').addEventListener('click', applyFilters);
});
